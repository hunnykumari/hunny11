create database TrainingDatabase 
ON (FILENAME="\C:\user\765294\TrainingDatabase.mdf"),
   (FILENAME="\C:\user\765294\TrainingDatabase_log.ldf")
    FOR ATTACH;
