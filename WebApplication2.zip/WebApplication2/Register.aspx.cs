﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
namespace WebApplication2
{
    public partial class Register : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["db1ConnectionString"].ToString());
                string insert = "insert into Registration values(@userid,@password,@usertype)";
                SqlCommand cmd = new SqlCommand(insert, conn);
                cmd.Parameters.AddWithValue("@userid", TextBox1.Text);
                cmd.Parameters.AddWithValue("@password", TextBox2.Text);
                cmd.Parameters.AddWithValue("@usertype", TXT3.Text);
                conn.Open();
                int a = cmd.ExecuteNonQuery();
                if (a != 0)
                { Response.Write("Record inserted in db");
                Response.Redirect("lOGIN.aspx");
                }
            }
            catch { }
        }

    }
}