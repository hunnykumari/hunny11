﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows;





namespace TMS
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        
        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TrainingDatabaseConnectionString"].ToString());
                String insert = "insert into registration values(@userId,@firstName,@lastName,@age,@gender,@contactNumber,@password,@email,@userType)";
                //String insert1 = "insert into registration(userId,firstName,lastName,age,gender,password,email,userType) values(@userId,@firstName,@lastName,@age,@gender,@password,@email,@userType)";

                SqlCommand cmd = new SqlCommand(insert, con);
               // SqlCommand cmd1 = new SqlCommand(insert1
                

                cmd.Parameters.AddWithValue("@userId", user_AdminId.Text);
                cmd.Parameters.AddWithValue("@firstName", firstName1.Text);
                cmd.Parameters.AddWithValue("@LastName", lastName.Text);
                cmd.Parameters.AddWithValue("@age", age.Text);
                cmd.Parameters.AddWithValue("@gender", DropDownList2.Text);
                if (contactNumber.Text != "")
                    cmd.Parameters.AddWithValue("@contactNumber", Convert.ToInt64(contactNumber.Text));
                else
                    cmd.Parameters.AddWithValue("@contactNumber", DBNull.Value);
                cmd.Parameters.AddWithValue("@password", password.Text);
                cmd.Parameters.AddWithValue("@email", email.Text);
                cmd.Parameters.AddWithValue("@userType", DropDownList1.Text);
                con.Open();


                int result = cmd.ExecuteNonQuery();
                 

                con.Close();
              
                Page.ClientScript.RegisterStartupScript(Page.GetType(),"scripts","<Script>alert('Your details are submitted successfully');</script>");
     
            }
           catch (Exception ex)
            {
               System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        
    }
}