﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace TMS
{
    public partial class ArrayTest : System.Web.UI.Page
    {
        string connStr = ConfigurationManager.ConnectionStrings["TrainingDatabaseConnectionString1"].ConnectionString;

        SqlCommand cmd;

        SqlDataAdapter sqlda;

        DataSet ds;

        string str;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                SqlConnection conn = new SqlConnection(connStr);

                conn.Open();

                str = "select userId,courseCode, completionDate,score from score where userId = '" + Session["user"].ToString() + "'";

                cmd = new SqlCommand(str, conn);

                int count = Convert.ToInt32(cmd.ExecuteScalar());

                if (count > 0)
                {

                    bind();

                    GridView1.Visible = true;

                }

                else
                {



                    GridView1.Visible = false;

                }



            }

            catch { }
        }

        private void bind()
        {

            try
            {
                SqlConnection conn = new SqlConnection(connStr);

                conn.Open();

                str = "select userId,courseCode, completionDate,score from score where userId like '" + Session["user"].ToString() + "'";

                cmd = new SqlCommand(str, conn);

                sqlda = new SqlDataAdapter(cmd);

                ds = new DataSet();

                sqlda.Fill(ds, "score");

                conn.Close();

                GridView1.DataSource = ds;

                GridView1.DataMember = "score";

                GridView1.DataBind();

            }
            catch { }
        }
    }
}