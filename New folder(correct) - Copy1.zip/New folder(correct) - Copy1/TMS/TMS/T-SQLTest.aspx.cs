﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace TMS
{
    public partial class T_SQLTest : System.Web.UI.Page
    {
        int score = 0;
        string s;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {s=TextBox1.Text;
            if (s.Equals("drop customer") || s.Equals( "Drop Customer") || s.Equals("DROP CUSTOMER")){
                score = 20;   
            }
            ViewState["score"] = score;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TrainingDatabaseConnectionString1"].ToString());

            string insert = "insert into score values(@userId,@courseCode,@completionDate,@score)";
            //string insert = "insert into score values('aa','dd','gg',20)";
            SqlCommand cmd = new SqlCommand(insert, con);



            cmd.Parameters.AddWithValue("@userId", Session["user"].ToString());
            //  Response.Write(Session["user"].ToString());
            cmd.Parameters.AddWithValue("@courseCode", Session["t"].ToString());
            //  Response.Write(Session["t"].ToString());
            DateTime d = DateTime.Now;

            cmd.Parameters.AddWithValue("@completionDate", d.ToShortDateString());
            //  Response.Write(d.ToShortDateString());
            cmd.Parameters.AddWithValue("@score", Convert.ToInt32(ViewState["score"]));
            //  Response.Write (ViewState["score"].ToString());
            con.Open();

            int a = cmd.ExecuteNonQuery();

            if (a != 0)
            {

                Response.Write("Report is ready!!Click on show report!! ");

               

            }

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("T-SQLReport.aspx");
        }
        
    }
}